'''Copyright (C) 2025 Aperturia FX
Created by Arvo Andre Radik
This file is part of Aperturia FX
Aperturia FX is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.


This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.


You should have received a copy of the GNU General Public License
along with this program; if not, see https://www.gnu.org
/licenses.'''

bl_info = {
    "name": "Aperturia FX Lite",
    "author": "Arvo Andre Radik",
    "version": (1, 0, 7),
    "blender": (4, 5, 0),
    "location": "Node Editor > Add > Compositor > Aperturia FX Lite",
    "description": "Fast lens effect node for Compositor",
    "category": "Compositing"
}

import bpy
import nodeitems_utils
import sys
import urllib.request
import re
import json
from nodeitems_utils import NodeCategory, NodeItem

GROUP_NAME = "Aperturia FX Lite"
LATEST_VERSION = None
LAST_CHECKED = None
CURRENT_VERSION = tuple(sys.modules[__name__].bl_info["version"])
CURRENT_VERSION_STR = ".".join(map(str, CURRENT_VERSION))

def get_latest_github_version():
    url = "https://github.com/Radikal404/AperturiaFX/tree/main/Extensions/Lite"
    try:
        with urllib.request.urlopen(url) as response:
            html = response.read().decode()
            matches = re.findall(r"Aperturia FX Lite v(\d+_\d+_\d+)\.zip", html)
            versions = [tuple(map(int, v.split("_"))) for v in matches]
            return max(versions) if versions else None
    except Exception as e:
        print(f"Error fetching GitHub versions: {e}")
        return None
    
def is_update_available(local, remote):
    return remote > local

def on_file_load(scene):
    global LATEST_VERSION
    try:
        restore_aperturia_full()  # purge + rebuild + restore node if it existed
    except Exception as e:
        print(f"[On Load] Restore failed: {e}")
        
    try:
        LATEST_VERSION = get_latest_github_version()
        print(f"[Aperturia] Latest version found: {LATEST_VERSION}")
    except Exception as e:
        print(f"[Aperturia] Version check failed: {e}")
        LATEST_VERSION = None

# === TEXTURE SETUP ===

def reset_color_noise_texture():
    tex_name = "FX_LiteColorNoise"
    if tex_name in bpy.data.textures:
        try:
            bpy.data.textures[tex_name].type = 'DISTORTED_NOISE'
            tex = bpy.data.textures[tex_name]
        except:
            bpy.data.textures.remove(bpy.data.textures[tex_name])
            tex = bpy.data.textures.new(tex_name, type='DISTORTED_NOISE')
    else:
        tex = bpy.data.textures.new(tex_name, type='DISTORTED_NOISE')

    tex.noise_basis = 'CELL_NOISE'
    tex.noise_distortion = 'CELL_NOISE'
    tex.distortion = 10.0
    tex.noise_scale = 0.01
    tex.nabla = 0.1
    tex.use_color_ramp = True

    ramp = tex.color_ramp
    while len(ramp.elements) > 3:
        ramp.elements.remove(ramp.elements[-1])
    while len(ramp.elements) < 3:
        ramp.elements.new(0.5)

    ramp.elements[0].position = 0.0
    ramp.elements[0].color = (1, 0, 0, 1)
    ramp.elements[1].position = 0.5
    ramp.elements[1].color = (0, 1, 0, 1)
    ramp.elements[2].position = 1.0
    ramp.elements[2].color = (0, 0, 1, 1)

def ensure_aperturia_textures(force=False):
    if "FX_LiteColorNoise" not in bpy.data.textures or bpy.data.textures["FX_LiteColorNoise"].type != 'DISTORTED_NOISE':
        reset_color_noise_texture()
    if "FX_LiteCompressionNoise" not in bpy.data.textures:
        bpy.data.textures.new(name="FX_LiteCompressionNoise", type='NOISE')

def snapshot_aperturia_node_state():
    """Capture compositor node placement, values, and links for Aperturia FX Lite."""
    nt = bpy.context.scene.node_tree
    if not nt:
        return None, None

    for node in nt.nodes:
        if node.type == "GROUP" and node.node_tree and node.node_tree.name == "Aperturia FX Lite":
            state = {
                "location": tuple(node.location),
                "width": getattr(node, "width", None),
                "height": getattr(node, "height", None),
                "inputs": {},
                "links_in": [],
                "links_out": []
            }
            # Capture input values
            for i, inp in enumerate(node.inputs):
                try:
                    state["inputs"][i] = inp.default_value
                except Exception:
                    pass
                for link in list(inp.links):
                    state["links_in"].append({
                        "from_node": link.from_node.name,
                        "from_socket": link.from_socket.name,
                        "to_index": i
                    })
            # Capture outgoing links
            for i, out in enumerate(node.outputs):
                for link in list(out.links):
                    state["links_out"].append({
                        "from_index": i,
                        "to_node": link.to_node.name,
                        "to_socket": link.to_socket.name
                    })
            return state, node
    return None, None

def restore_aperturia_full():
    # 1. Snapshot compositor node state
    state, old_node = snapshot_aperturia_node_state()

    # 2. Remove the compositor node itself
    nt = bpy.context.scene.node_tree
    if old_node:
        nt.nodes.remove(old_node)

    # 3. Cleanup all Aperturia assets
    cleanup_aperturia_lite_assets()

    # 4. Recreate textures/images
    ensure_aperturia_textures(force=True)

    # 5. Rebuild node groups
    lite_node_group_build()

    # 6. Re‑instantiate compositor node
    if state:
        new_node = nt.nodes.new("CompositorNodeGroup")
        new_node.node_tree = bpy.data.node_groups.get("Aperturia FX Lite")

        # Restore placement
        new_node.location = state["location"]
        if state["width"] is not None:
            new_node.width = state["width"]
        if state["height"] is not None:
            new_node.height = state["height"]

        # Restore values
        for i, val in state["inputs"].items():
            try:
                new_node.inputs[i].default_value = val
            except Exception:
                pass

        # Reconnect links
        for link in state["links_in"]:
            from_node = nt.nodes.get(link["from_node"])
            if from_node:
                out_socket = from_node.outputs.get(link["from_socket"])
                in_socket = new_node.inputs[link["to_index"]]
                if out_socket and in_socket:
                    nt.links.new(out_socket, in_socket)

        for link in state["links_out"]:
            to_node = nt.nodes.get(link["to_node"])
            if to_node:
                out_socket = new_node.outputs[link["from_index"]]
                in_socket = to_node.inputs.get(link["to_socket"])
                if out_socket and in_socket:
                    nt.links.new(out_socket, in_socket)

        print("[Restore] Aperturia FX Lite rebuilt, placed, reconfigured, and rewired.")
    else:
        print("[Restore] Aperturia FX Lite rebuilt (no compositor node was present).")

    return True

def purge_aperturia():
    """Remove all Aperturia-related datablocks, including suffixed duplicates."""
    base_names = [
        "Aperturia FX Lite"
    ]

    def matches(name):
        return any(name == base or name.startswith(base + ".") for base in base_names)

    deleted_total = 0
    pass_count = 0

    while True:
        deleted_this_pass = 0
        pass_count += 1

        # Node Groups
        for ng in list(bpy.data.node_groups):
            if matches(ng.name):
                ng.use_fake_user = False
                if ng.users == 0:
                    bpy.data.node_groups.remove(ng)
                    deleted_this_pass += 1

        # Textures
        for tex in list(bpy.data.textures):
            if matches(tex.name):
                tex.use_fake_user = False
                if tex.users == 0:
                    bpy.data.textures.remove(tex)
                    deleted_this_pass += 1

        deleted_total += deleted_this_pass
        if deleted_this_pass == 0:
            break

    print(f"[Purge] Total purged: {deleted_total} assets in {pass_count} passes.")
    return deleted_total

def lite_node_group_build():
        ensure_aperturia_textures(force=True)
        if "Aperturia FX Lite" in bpy.data.node_groups:
            bpy.data.node_groups.remove(bpy.data.node_groups["Aperturia FX Lite"])
        group, node_map = create_custom_node_group()
        if group and node_map:
            wire_custom_node_group(group, node_map)
        return None

# === NODE GROUP BUILDER ===
def create_custom_node_group():
    group_name = "Aperturia FX Lite"
    if group_name in bpy.data.node_groups:
        print(">>> Node group already exists. Skipping creation.")
        return None, None

    ng = bpy.data.node_groups.new(name=group_name, type='CompositorNodeTree')
    nodes = ng.nodes
    links = ng.links
    ng.use_fake_user = True
    ng.color_tag = 'FILTER'

    # Interface sockets
    ng.interface.new_socket(name="Image", in_out='INPUT', socket_type='NodeSocketColor')
    ng.interface.new_socket(name="Image", in_out='OUTPUT', socket_type='NodeSocketColor')

    # Add Input/Output nodes
    input_node = nodes.new("NodeGroupInput")
    input_node.location = (-4000, 0)
    output_node = nodes.new("NodeGroupOutput")
    output_node.location = (4000, -550)

    # === NODE INITIALIZATION ===
    def new(name, bl_idname, x=0, y=0):
        n = nodes.new(type=bl_idname)
        n.name = name
        n.label = name
        n.location = (x, y)
        return n
    
    node_map = {n.name: n for n in nodes}

#--NODE SETUP FOR: BEST CAMERA QUALITY PRESET
    ellipse = new("Ellipse Mask", "CompositorNodeEllipseMask", -3300, 700)
    ellipse.mask_width = 1.0
    ellipse.mask_height = 0.75
    blur = new("Blur", "CompositorNodeBlur", -2950, 700)
    blur.filter_type = "GAUSS"
    blur.use_variable_size = True
    blur.size_x = 250
    blur.size_y = 250
    glare = new("Glare", "CompositorNodeGlare", -2950, 420)
    glare.glare_type = "BLOOM"
    glare.inputs["Threshold"].default_value = 25
    glare.inputs["Smoothness"].default_value = 1.0
    glare.inputs["Maximum"].default_value = 5.0
    glare.inputs["Size"].default_value = 1.0
    mix = new("Mix", "CompositorNodeMixRGB", -2450, 330);mix.blend_type = 'MULTIPLY'
    mix.inputs[0].default_value = 0.3

    ld = []
    ld_0 = new("Lens Distortion", "CompositorNodeLensdist", -2000, 700)
    ld_0.use_jitter = True
    ld_1 = new("Lens Distortion.001", "CompositorNodeLensdist", -1800, 500)
    ld_1.use_jitter = True
    ld_2 = new("Lens Distortion.002", "CompositorNodeLensdist", -2000, 240)
    ld_3 = new("Lens Distortion.003", "CompositorNodeLensdist", -2150, -50)
    ld_4 = new("Lens Distortion.004", "CompositorNodeLensdist", -900, 360)
    ld_4.use_fit = True
    ld_5 = new("Lens Distortion.005", "CompositorNodeLensdist", 540, 460)
    ld_5.use_jitter = True

    rgb_to_bw = new("RGB to BW", "CompositorNodeRGBToBW", -2000, -50)
    rgb_to_bw_2 = new("RGB to BW.001", "CompositorNodeRGBToBW", 760, 360)
    denoise1 = new("Denoise", "CompositorNodeDenoise", -2000, 490)
    denoise1.use_hdr = True
    denoise2 = new("Denoise.001", "CompositorNodeDenoise", -1800, 310)
    denoise2.use_hdr = True
    denoise3 = new("Denoise.002", "CompositorNodeDenoise", -1800, -40)
    denoise3.use_hdr = False
    denoise4 = new("Denoise.003", "CompositorNodeDenoise", -50, 180)

    mix_1 = new("Mix.001", "CompositorNodeMixRGB", -1600, 670); mix_1.blend_type = 'DARKEN'
    mix_1.inputs[0].default_value = 0.5
    mix_2 = new("Mix.002", "CompositorNodeMixRGB", -1300, 440)
    mix_2.inputs[0].default_value = 0.15
    mix_3 = new("Mix.003", "CompositorNodeMixRGB", -1090, 360)
    mix_4 = new("Mix.004", "CompositorNodeMixRGB", -630, 360); mix_4.blend_type = 'OVERLAY'
    mix_4.inputs[0].default_value = 0.1
    mix_5 = new("Mix.005", "CompositorNodeMixRGB", 370, 265)
    mix_5.inputs[0].default_value = 0.5
    mix_6 = new("Mix.006", "CompositorNodeMixRGB", 1060, 200); mix_6.blend_type = 'LIGHTEN'
    mix_6.inputs[0].default_value = 0.25

    cc = new("Color Correction", "CompositorNodeColorCorrection", -80, 460)
    cc.shadows_contrast = 0.9
    alpha_over = new("Alpha Over - DSLR", "CompositorNodeAlphaOver", 1880, 235); alpha_over.inputs[0].default_value = 0.002
    pixelate = new("Pixelate", "CompositorNodePixelate", 1360, 330); pixelate.pixel_size = 3

    texture_cn = new("FX_LiteColorNoise", "CompositorNodeTexture", -1200, 710); texture_cn.texture = bpy.data.textures.get("FX_LiteColorNoise")
    blur_cn = new("Blur.001", "CompositorNodeBlur", -890, 710)
    blur_cn.use_variable_size = True
    blur_cn.size_x = 20
    blur_cn.size_y = 20
    texture_comp = new("FX_LiteCompressionNoise", "CompositorNodeTexture", 980, 570); texture_comp.texture = bpy.data.textures.get("FX_LiteCompressionNoise")
    map_value = new("Map Value", "CompositorNodeMapValue", 700, 860)    

    node_map = {n.name: n for n in nodes}
    return ng, node_map

def wire_custom_node_group(group, node_map):
    link = group.links
    gi = node_map["Group Input"].outputs
    go = node_map["Group Output"].inputs
    
    # Connect vignette mask
    link.new(node_map["Ellipse Mask"].outputs[0], node_map["Blur"].inputs[0])
    link.new(node_map["Blur"].outputs[0], node_map["Mix"].inputs[2])
    link.new(node_map["Glare"].outputs[0], node_map["Mix"].inputs[1])
    link.new(gi["Image"], node_map["Glare"].inputs[0])

    # Pre-distort chain
    link.new(node_map["Mix"].outputs[0], node_map["Lens Distortion"].inputs[0])
    link.new(node_map["Mix"].outputs[0], node_map["Denoise"].inputs[0])
    link.new(node_map["Mix"].outputs[0], node_map["Lens Distortion.002"].inputs[0])
    link.new(node_map["Mix"].outputs[0], node_map["Lens Distortion.003"].inputs[0])
    link.new(node_map["Denoise"].outputs[0], node_map["Lens Distortion.001"].inputs[0])

    # Stack merge
    link.new(node_map["Lens Distortion"].outputs[0], node_map["Mix.001"].inputs[1])
    link.new(node_map["Lens Distortion.001"].outputs[0], node_map["Mix.001"].inputs[2])
    link.new(node_map["Lens Distortion.002"].outputs[0], node_map["Denoise.001"].inputs[0])
    link.new(node_map["Lens Distortion.003"].outputs[0], node_map["RGB to BW"].inputs[0])
    link.new(node_map["RGB to BW"].outputs[0], node_map["Denoise.002"].inputs[0])
    link.new(node_map["Denoise.001"].outputs[0], node_map["Mix.002"].inputs[1])
    link.new(node_map["Mix.001"].outputs[0], node_map["Mix.002"].inputs[2])
    link.new(node_map["Mix.002"].outputs[0], node_map["Mix.003"].inputs[1])
    link.new(node_map["Denoise.001"].outputs[0], node_map["Mix.003"].inputs[2])
    link.new(node_map["Denoise.002"].outputs[0], node_map["Mix.003"].inputs[0])

    # Post-distortion
    link.new(node_map["Mix.003"].outputs[0], node_map["Lens Distortion.004"].inputs[0])

    # Color noise overlay
    link.new(node_map["Lens Distortion.004"].outputs[0], node_map["Mix.004"].inputs[1])
    link.new(node_map["FX_LiteColorNoise"].outputs[1], node_map["Blur.001"].inputs[0])
    link.new(node_map["Blur.001"].outputs[0], node_map["Mix.004"].inputs[2])

    # Shadow contrast & denoise
    link.new(node_map["Mix.004"].outputs[0], node_map["Color Correction"].inputs[0])
    link.new(node_map["Mix.004"].outputs[0], node_map["Denoise.003"].inputs[0])
    link.new(node_map["Color Correction"].outputs[0], node_map["Mix.005"].inputs[1])
    link.new(node_map["Denoise.003"].outputs[0], node_map["Mix.005"].inputs[2])

    # Lighten merge
    link.new(node_map["Mix.005"].outputs[0], node_map["Lens Distortion.005"].inputs[0])
    link.new(node_map["Lens Distortion.005"].outputs[0], node_map["RGB to BW.001"].inputs[0])
    link.new(node_map["Mix.005"].outputs[0], node_map["Mix.006"].inputs[1])
    link.new(node_map["RGB to BW.001"].outputs[0], node_map["Mix.006"].inputs[2])

    # Scale and alpha composite
    link.new(node_map["Mix.006"].outputs[0], node_map["Alpha Over - DSLR"].inputs[1])
    link.new(node_map["Pixelate"].outputs[0], node_map["Alpha Over - DSLR"].inputs[2])
    link.new(node_map["Alpha Over - DSLR"].outputs[0], go["Image"])

    # Final FX texture link
    link.new(node_map["Map Value"].outputs[0], node_map["FX_LiteCompressionNoise"].inputs[0])
    link.new(node_map["FX_LiteCompressionNoise"].outputs[0], node_map["Pixelate"].inputs[0])
    
    # Animate mapping value
    fcurve = node_map["Map Value"].inputs[0].driver_add("default_value")
    fcurve.driver.expression = "frame"
    
    return {'FINISHED'}

# === CUSTOM NODE CLASSES ===

class APERTURIA_LITE_OT_download_update(bpy.types.Operator):
    bl_idname = "aperturia_lite.download_update"
    bl_label = "Download Latest Version"
    bl_description = "Downloads the latest version"

    filepath: bpy.props.StringProperty(subtype="FILE_PATH")

    def execute(self, context):
        global LATEST_VERSION
        if not LATEST_VERSION:
            self.report({'ERROR'}, "Could not find latest version.")
            return {'CANCELLED'}

        version_str = "_".join(map(str, LATEST_VERSION))
        zip_name = f"Aperturia FX Lite v{version_str}.zip"
        download_url = f"https://github.com/Radikal404/AperturiaFX/raw/main/Extensions/Lite/{zip_name}"

        try:
            urllib.request.urlretrieve(download_url, self.filepath)
            self.report({'INFO'}, f"Downloaded to {self.filepath}")
        except Exception as e:
            self.report({'ERROR'}, f"Download failed: {e}")
        return {'FINISHED'}

    def invoke(self, context, event):
        global LATEST_VERSION
        if not LATEST_VERSION:
            self.report({'ERROR'}, "Could not determine latest version.")
            return {'CANCELLED'}

        version_str = "_".join(map(str, LATEST_VERSION))
        default_filename = f"Aperturia FX Lite v{version_str}.zip"
        self.filepath = bpy.path.abspath(f"//{default_filename}")
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

class APERTURIA_LITE_OT_Refresh(bpy.types.Operator):
    bl_idname = "aperturia_lite.refresh_node_group"
    bl_label = "Restore Aperturia FX Lite"
    bl_description = "Checks and restores Aperturia FX Lite node group and textures"

    def execute(self, context):
        restored = restore_aperturia_full()
        if restored:
            self.report({'INFO'}, "Aperturia FX Lite was rebuilt.")
        else:
            self.report({'INFO'}, "Aperturia FX Lite is already intact.")
        return {'FINISHED'}
    
class APERTURIA_LITE_OT_Optimize(bpy.types.Operator):
    bl_idname = "aperturia.optimize"
    bl_label = "Optimize"
    bl_description = "Optimize current scene to make the node more responsive"

    def execute(self, context):
        scene = context.scene
        prefs = context.preferences
        
        if scene.render.compositor_device != 'GPU' or scene.render.compositor_denoise_device != 'GPU':
            scene.render.compositor_device = 'GPU'
            scene.render.compositor_denoise_device = 'GPU'

        self.report({'INFO'}, "Scene optimized: compositor + denoising set to GPU.")
        return {'FINISHED'}

class APERTURIA_LITE_PT_Tools(bpy.types.Panel):
    bl_label = "Aperturia FX Lite Tools"
    bl_idname = "APERTURIA_LITE_PT_Tools"
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_category = "Aperturia"  # Shared category

    def draw(self, context):
        layout = self.layout
        
        layout.label(text=f"Version: {CURRENT_VERSION_STR}")

        if LATEST_VERSION and is_update_available(CURRENT_VERSION, LATEST_VERSION):
            layout.operator("aperturia_lite.download_update", icon='FILE_NEW')
        elif LATEST_VERSION:
            layout.label(text="Up to date")
        else:
            layout.label(text="No update info yet")
        
        layout.operator("aperturia_lite.refresh_node_group", icon='FILE_REFRESH')
        layout.operator("aperturia.optimize", icon='MODIFIER')


class CompositorNodeAperturiaFXLite(bpy.types.Node):
    bl_idname = "CompositorNodeAperturiaFXLite"
    bl_label = "Quick lens effects (Lite)"
    bl_icon = 'CAMERA_DATA'

    def init(self, context):
        group_name = "Aperturia FX Lite"
        if group_name in bpy.data.node_groups:
            self.node_tree = bpy.data.node_groups[group_name]

    @classmethod
    def poll(cls, context):
        return context.space_data.tree_type == "CompositorNodeTree"


class AperturiaFXLiteCategory(NodeCategory):
    @classmethod
    def poll(cls, context):
        return context.space_data.tree_type == "CompositorNodeTree"


node_categories = [
    AperturiaFXLiteCategory("APERTURIA_NODES_LITE", "Aperturia FX Lite", items=[
        NodeItem("CompositorNodeAperturiaFXLite"),
    ]),
]

# === REGISTER / UNREGISTER ===

classes = (
    CompositorNodeAperturiaFXLite,
    APERTURIA_LITE_OT_download_update,
    APERTURIA_LITE_OT_Refresh,
    APERTURIA_LITE_OT_Optimize,
    APERTURIA_LITE_PT_Tools,
)

def on_file_load_lite(scene):
    check_aperturia_lite_integrity()
    
def cleanup_aperturia_lite_assets():
    base_names = [
        "Aperturia FX Lite", "FX_LiteColorNoise", "FX_LiteCompressionNoise"
    ]

    def matches(name):
        return any(name == base or name.startswith(base + ".") for base in base_names)

    for ng in list(bpy.data.node_groups):
        if matches(ng.name):
            ng.use_fake_user = False
            bpy.data.node_groups.remove(ng)

    for tex in list(bpy.data.textures):
        if matches(tex.name):
            tex.use_fake_user = False
            bpy.data.textures.remove(tex)

    print("All Aperturia assets removed.")

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    from nodeitems_utils import register_node_categories
    nodeitems_utils.register_node_categories("APERTURIA_FX_LITE", node_categories)

    if on_file_load_lite not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(on_file_load_lite)

    from bpy.app.timers import register as delay

    def deferred_node_group_build():
        ensure_aperturia_textures(force=True)
        if "Aperturia FX Lite" in bpy.data.node_groups:
            bpy.data.node_groups.remove(bpy.data.node_groups["Aperturia FX Lite"])
        group, node_map = create_custom_node_group()
        if group and node_map:
            wire_custom_node_group(group, node_map)
        return None

    delay(deferred_node_group_build, first_interval=1.0)
    
    try:
        restore_aperturia_full()
    except Exception as e:
        print("Aperturia FX Lite integrity check failed:", e) 

def unregister():
    from nodeitems_utils import unregister_node_categories
    nodeitems_utils.unregister_node_categories("APERTURIA_FX_LITE")

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

    if on_file_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(on_file_load)
        
    cleanup_aperturia_lite_assets()